﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMaxGal = New System.Windows.Forms.Label()
        Me.lblMilesDriven = New System.Windows.Forms.Label()
        Me.lblMPG = New System.Windows.Forms.Label()
        Me.txtMaxGal = New System.Windows.Forms.TextBox()
        Me.txtMilesDriven = New System.Windows.Forms.TextBox()
        Me.txtMPG = New System.Windows.Forms.TextBox()
        Me.btnCalcMPG = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblMaxGal
        '
        Me.lblMaxGal.AutoSize = True
        Me.lblMaxGal.Location = New System.Drawing.Point(68, 51)
        Me.lblMaxGal.Name = "lblMaxGal"
        Me.lblMaxGal.Size = New System.Drawing.Size(89, 13)
        Me.lblMaxGal.TabIndex = 0
        Me.lblMaxGal.Text = "Maximum Gallons"
        '
        'lblMilesDriven
        '
        Me.lblMilesDriven.AutoSize = True
        Me.lblMilesDriven.Location = New System.Drawing.Point(68, 100)
        Me.lblMilesDriven.Name = "lblMilesDriven"
        Me.lblMilesDriven.Size = New System.Drawing.Size(127, 13)
        Me.lblMilesDriven.TabIndex = 1
        Me.lblMilesDriven.Text = "Miles Driven on Full Tank"
        '
        'lblMPG
        '
        Me.lblMPG.AutoSize = True
        Me.lblMPG.Location = New System.Drawing.Point(68, 156)
        Me.lblMPG.Name = "lblMPG"
        Me.lblMPG.Size = New System.Drawing.Size(83, 13)
        Me.lblMPG.TabIndex = 2
        Me.lblMPG.Text = "Miles Per Gallon"
        '
        'txtMaxGal
        '
        Me.txtMaxGal.Location = New System.Drawing.Point(261, 48)
        Me.txtMaxGal.Name = "txtMaxGal"
        Me.txtMaxGal.Size = New System.Drawing.Size(100, 20)
        Me.txtMaxGal.TabIndex = 3
        '
        'txtMilesDriven
        '
        Me.txtMilesDriven.Location = New System.Drawing.Point(261, 97)
        Me.txtMilesDriven.Name = "txtMilesDriven"
        Me.txtMilesDriven.Size = New System.Drawing.Size(100, 20)
        Me.txtMilesDriven.TabIndex = 4
        '
        'txtMPG
        '
        Me.txtMPG.Location = New System.Drawing.Point(261, 164)
        Me.txtMPG.Name = "txtMPG"
        Me.txtMPG.Size = New System.Drawing.Size(100, 20)
        Me.txtMPG.TabIndex = 5
        '
        'btnCalcMPG
        '
        Me.btnCalcMPG.BackColor = System.Drawing.Color.Tomato
        Me.btnCalcMPG.Location = New System.Drawing.Point(71, 313)
        Me.btnCalcMPG.Name = "btnCalcMPG"
        Me.btnCalcMPG.Size = New System.Drawing.Size(103, 23)
        Me.btnCalcMPG.TabIndex = 6
        Me.btnCalcMPG.Text = "Calculate MPG"
        Me.btnCalcMPG.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.Tomato
        Me.btnClear.Location = New System.Drawing.Point(233, 313)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Tomato
        Me.btnExit.Location = New System.Drawing.Point(383, 313)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(663, 401)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalcMPG)
        Me.Controls.Add(Me.txtMPG)
        Me.Controls.Add(Me.txtMilesDriven)
        Me.Controls.Add(Me.txtMaxGal)
        Me.Controls.Add(Me.lblMPG)
        Me.Controls.Add(Me.lblMilesDriven)
        Me.Controls.Add(Me.lblMaxGal)
        Me.Name = "Form1"
        Me.Text = "Miles Per Gallon Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMaxGal As Label
    Friend WithEvents lblMilesDriven As Label
    Friend WithEvents lblMPG As Label
    Friend WithEvents txtMaxGal As TextBox
    Friend WithEvents txtMilesDriven As TextBox
    Friend WithEvents btnCalcMPG As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtMPG As TextBox
End Class
