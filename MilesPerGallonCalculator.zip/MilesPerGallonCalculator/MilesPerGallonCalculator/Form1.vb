﻿Public Class Form1

    Dim maxGallons As Decimal
    Dim milesDriven As Decimal
    Dim milesPerGallon As Decimal

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtMPG.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        maxGallons = 0
        milesDriven = 0
        milesPerGallon = 0

        txtMaxGal.Clear()
        txtMilesDriven.Clear()
        txtMPG.Clear()

    End Sub

    Private Sub btnCalcMPG_Click(sender As Object, e As EventArgs) Handles btnCalcMPG.Click

        Try

            maxGallons = txtMaxGal.Text
            milesDriven = txtMilesDriven.Text
            milesPerGallon = (milesDriven / maxGallons)

            txtMPG.Text = milesPerGallon
        Catch ex As Exception
            MessageBox.Show(MessageBoxButtons.OK, "Invalid data entered")
            maxGallons = 0
            milesDriven = 0
            milesPerGallon = 0

            txtMaxGal.Clear()
            txtMilesDriven.Clear()
            txtMPG.Clear()
        End Try


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
